import java.io.Serializable;

public class Carro implements Serializable{
	private String modelo;
	private String cor;
	private PortaMalas pm;

	public Carro(){}
	public Carro(String modelo, String cor, int litros) {
		this.modelo = modelo;
		this.cor = cor;
		this.pm = new PortaMalas(litros);
	}
	public String getCor() { 
		return cor; 
	}
	public String getModelo() { 
		return modelo; 
	}
	public void setCor(String cor) { 
		this.cor = cor; 
	}
	public void setModelo(String modelo) { 
		this.modelo = modelo; 
	}
	public PortaMalas getPm() { 
		return pm; 
	}
	public void setPm(PortaMalas pm) { 
		this.pm = pm; 
	}
}