import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Principal2 {
	public static void main(String args[]){
		Carro carro1, carro2, carro3;
		try {
			FileInputStream inFile = new FileInputStream("carros.ser");
			ObjectInputStream in = new ObjectInputStream(inFile);
			carro1 = (Carro) in.readObject();
			carro2 = (Carro) in.readObject();
			carro3 = (Carro) in.readObject();
			in.close();
			System.out.println("Carro 1: "+carro1.getModelo()+" - "
				+carro1.getCor()+" - "+carro1.getPm().getLitros());
			System.out.println("Carro 2: "+carro2.getModelo()+" - "
				+carro2.getCor()+" - "+carro2.getPm().getLitros());
			System.out.println("Carro 3: "+carro3.getModelo()+" - "
				+carro3.getCor()+" - "+carro3.getPm().getLitros());
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado!");
		} catch (IOException e) {
			System.out.println("Erro na leitura dos dados!");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Classe não encontrada!");
			e.printStackTrace();
		}
	}
}