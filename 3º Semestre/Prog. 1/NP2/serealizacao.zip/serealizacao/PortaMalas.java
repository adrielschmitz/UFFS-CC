import java.io.Serializable;

public class PortaMalas implements Serializable {
	private int litros;
	public PortaMalas() { }
	public PortaMalas(int litros) { this.litros = litros; }
	public int getLitros() { return litros; }
	public void setLitros(int litros) { this.litros = litros; }
}