import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Principal1 {
	public static void main(String args[]){
		Carro carro1, carro2, carro3;
		carro1 = new Carro("Fusca", "verde", 200);
		carro2 = new Carro("Gol", "azul", 300);
		carro3 = new Carro("Kombi", "branca", 400);
		try{
			FileOutputStream outFile = new FileOutputStream("carros.ser");
			ObjectOutputStream os = new ObjectOutputStream(outFile);
			os.writeObject(carro1);
			os.writeObject(carro2);
			os.writeObject(carro3);
			os.close(); 
			System.out.println("Serialização concluída!");
		}catch (IOException e){
			System.out.println("Problemas na serialização!");
			e.printStackTrace();
		}
	}
}