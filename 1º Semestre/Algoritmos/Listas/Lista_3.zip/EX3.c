#include <stdio.h>
#include <stdlib.h>

int main(){
	int a = 1, b = 1;

	for(a = 1; a < 5; a++){
		for(b = 1;b < 5;b++){
			if(a == 1)
				printf("%5d", b);
			 else if(a == 2){
				printf("%5d", b * 2);
			 else if(a == 3)
				printf("%5d", b * 3);
			 else if(a == 4)
				printf("%5d", b * 4);
			
		}
		printf("\n");
	}
}
