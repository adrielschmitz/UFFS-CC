#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void){
	int tempo, velocidade, distancia, consumo;

	printf("Digite o tempo: ");
	scanf("%d", &tempo);

	printf("Digite a velocidade: ");
	scanf("%d", &velocidade);

	printf("Digite o distância: ");
	scanf("%d", &distancia);

	printf("Digite o valor do consumo do seu carro: ");
	scanf("%d", &consumo);

	printf("%.3f\n", ((float)distancia)/consumo);
}
