#include <stdio.h>
#include <stdlib.h>

int main(void){
	char star[7] = " ";
	int j = 0, j;

	while(i < 7){
		star[j] = '*';
		printf("%s\n", star);
		j++;
	}
}
