#include <stdio.h>
#include <stdlib.h>

int main(void){
	int i;

	printf("Digite um valor qualquer:");
	scanf("%d", &i);

	printf("Antecessor: %d\nSucessor: %d\n", i - 1, i + 1);
}
