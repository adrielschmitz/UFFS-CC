#include <stdio.h>
#include <stdlib.h>

int main(){
	int entrada;

	printf("Digite um valor: ");
	scanf("%d", &entrada);

	if(entrada % 10 == 0) printf("%d é divisivel por 10\n", entrada);
	if(entrada % 5 == 0) printf("%d é divisivel por 5\n", entrada);
	if(entrada % 2 == 0) printf("%d é divisivel por 2\n", entrada);
	else printf("%d não é divisivel por 10 ou 5 ou 2\n", entrada);

}
