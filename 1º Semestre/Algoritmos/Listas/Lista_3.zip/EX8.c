#include <stdio.h>
#include <stdlib.h>

int main(){

	float salario, prestacao;

	printf("Digite o valor do seu salário: ");
	scanf("%f", &salario);

	printf("Digite o valor da prestação: ");
	scanf("%f", &prestacao);

	salario *= 0.2;

	if(prestacao > salario) printf("Empréstimo não pode ser concedido.\n");
		else printf("Empréstimo pode ser concedido.\n");
	
}
