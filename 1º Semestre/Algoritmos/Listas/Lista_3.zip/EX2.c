#include <stdio.h>
#include <stdlib.h>

int main(){
	int i, j, k, soma = 0;

	printf("Digite a quantidade de valores para serem somados: ");
	scanf("%d", &i);

	for(j = 0;j < i;j++){
		printf("Digite o valor do %dº número: ", j + 1);
		scanf("%d", &k);

		soma += k;
	}

	printf("%d\n", soma);
}
