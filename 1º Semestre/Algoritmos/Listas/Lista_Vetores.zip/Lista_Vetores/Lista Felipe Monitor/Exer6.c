#include <stdio.h>
#include <string.h>

int verifica(char str[]){
	int contA = 0, contE = 0, contI = 0, contO = 0, contU = 0, i;
	for(i=0; i<strlen(str); i++){
		if(str[i] == 'a' || str[i] == 'A'){
			contA++;
		}if(str[i] == 'e' || str[i] == 'E'){
			contE++;
		}if(str[i] == 'i' || str[i] == 'I'){
			contI++;
		}if(str[i] == 'o' || str[i] == 'O'){
			contO++;
		}if(str[i] == 'u' || str[i] == 'U'){
			contU++;
		}
	}
	if(contA && contE && contI && contO && contU){
		return 1;
	}else{
		return 0;
	}
}


int main(){
	int i, tam;
	char str[100], strInv[100];
	scanf("%s", str);
	tam = strlen(str);
	if(verifica(str)){
		for(i=0; i<tam; i++){
			strInv[tam - i - 1] = str[i];
		}
		if(strcmp(str, strInv) == 0){
			printf("Eh uma string bacanuda! \n");
		}else{
			printf("Nao eh uma string bacanuda!\n");
		}
	}else{
		printf("Nao eh uma string bacanuda!\n");
	}
	return 0;
}