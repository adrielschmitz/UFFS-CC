#include <stdio.h>

int main(){
	int n, i;
	scanf("%d", &n);
	int vet[n];
	for(i=1; i<=n; i++){
		scanf("%d", &vet[i]);
	}
	for(i=1; i<=n; i++){
		if((vet[i] % 2 == 0 && i % 2 == 0)  || (vet[i] % 2 != 0 && i % 2 != 0)){
			printf("%d ", vet[i]);
		}
	}
	printf("\n");
	
	return 0;
}