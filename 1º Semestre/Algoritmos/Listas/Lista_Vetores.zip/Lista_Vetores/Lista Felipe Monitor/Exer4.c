#include <stdio.h>

int main(){
	int n, aux, i, j;
	scanf("%d", &n);
	int vet[n];
	for(i=0; i<n; i++){
		scanf("%d", &vet[i]);
	}
	for(i=0; i<n; i++){
		for(j=0; j<n; j++){
			if(vet[i] < vet[j]){
				aux = vet[i];
				vet[i] = vet[j];
				vet[j] = aux;
			}
		}
	}
	for(i=0; i<n; i++){
		printf("%d ", vet[i]);
	}
	printf("\n");
	for(i--; i>=0; i--){
		printf("%d ", vet[i]);
	}
	printf("\n");
	return 0;
}