#include <stdio.h>

int main(){
	int n, i;
	scanf("%d",& n);
	int vet1[n], vet2[n];
	for(i=0; i<n; i++){
		scanf("%d", &vet1[i]);
	}
	for(i=0; i<n; i++){
		scanf("%d", &vet2[i]);
	}
	for(i=0; i<n; i++){
		if(vet1[i] >= vet2[i]){
			printf("%d ", vet1[i]);
		}else{
			printf("%d ", vet2[i]);
		}
	}
	printf("\n");
	
	return 0;
}