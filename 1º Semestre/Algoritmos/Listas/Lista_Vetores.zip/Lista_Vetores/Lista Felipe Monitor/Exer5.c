#include <stdio.h>
#include <string.h>

int main(){
	int cont = 0, cont2, i, j;
	char str1[100], str2[100];
	scanf("%s", str1);
	scanf(" %[^\n]", str2);
	for(i=0; i<strlen(str2); i++){
		if(str1[0] == str2[i]){
			cont2 = 0;
			for(j=0; j<strlen(str1); j++){
				if(str1[j] == str2[i+j]){
					cont2++;
				}else{
					break;
				}
			}
			if(cont2 == strlen(str1)){
				cont++;
			}
		}
	}
	printf("A palavra %s aparece %d vezes\n", str1, cont);

	return 0;
}