#include <stdio.h>
#include <stdlib.h>
#define n 5

int main(){
	float vet[n], total=0;
	int i;
	printf("Informe o valor dos salarios.\n");
	for (i=0; i<n ; i++){
		scanf ("%f", &vet[i]);
		if(vet[i]>1000){
			printf("Salário = %.2f\n", vet[i]);
		} else{
			total = (vet[i]*10)/100;
			vet[i] += total;
			printf("Salário alterado = %.2f\n", vet[i]);		
		}
	}	
	return 0;
}