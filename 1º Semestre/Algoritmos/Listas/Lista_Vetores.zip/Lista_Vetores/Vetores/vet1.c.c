#include <stdio.h>
#include <stdlib.h>
#define n 10

int main(){
	float vet[n], aux=1;
	int  i;
	printf("Informe o valor dos salarios.\n");
	for (i=0 ; i<n ; i++){
		scanf ("%f", &vet[i]);
		if (vet[i]>aux){
			aux = vet[i];
		}
	}
	printf("Maior salário informado foi: %.2f\n", aux);

	return 0;
}
