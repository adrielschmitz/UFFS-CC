#include <stdio.h>
#include <stdlib.h>

int main(){
	int: n, i;
	scanf ("%d", &n);
	printf("Informe o numero de entrada.\n");
	float vet[n], media;	
	for (i=0; i<n ; i++){
		printf("Informe um valor\n");
		scanf ("%f", &vet[i]);
		media += vet[i]; 
	}
	printf("Média = %.2f\n", media/=n);

	return 0;
}