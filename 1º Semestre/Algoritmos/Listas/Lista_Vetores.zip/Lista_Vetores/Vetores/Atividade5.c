/*Leonardo Werlang					Algoritmos: Turma A
Faça um algoritmo que leia e armazene 5 valores inteiros em um vetor Vet1. Leia outros 5 valores
inteiros e armazene em um vetor Vet2. A partir destes valores lidos, mostre na tela:
- a soma dos elementos de cada vetor, nas respectivas posições;
- a diferença dos elementos de cada vetor, nas respectivas posições;
- o produto dos elementos de cada vetor, nas respectivas posições;
- a divisão entre os elementos de cada vetor, nas respectivas posições.
*/

#include <stdio.h>

int main(){
	int vet[5], vet2[5], n, i;
	printf("Digite os 5 primeiors numeros: ");
	for(i=0; i<5; i++){
		scanf("%d", &n);
		vet[i] = n;
	}
	printf("Digite os outros 5 numeros: ");
	for(i=0; i<5; i++){
		scanf("%d", &n);
		vet2[i] = n;
	}
	for(i=0; i<5; i++){
		printf("\nA soma dos vetores na posiçao %d eh: %d\n", i+1, vet[i]+vet2[i]);
		printf("A diferenca dos vetores na posiçao %d eh: %d\n", i+1, vet[i]-vet2[i]);
		printf("O produto dos vetores na posiçao %d eh: %d\n", i+1, vet[i]*vet2[i]);
		printf("A divisao dos vetores na posiçao %d eh: %.2lf\n", i+1, (double)vet[i]/vet2[i]);
	}
	return 0;
}