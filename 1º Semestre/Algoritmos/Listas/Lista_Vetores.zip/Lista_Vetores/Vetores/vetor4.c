#include <stdio.h>
#include <stdlib.h>

int main(){
	int n, i;
	printf("Informe o número de alunos.\n");
	scanf("%d", &n);
	float vetp1[n], vetp2[n], media[n];
	for (i=1; i<=n; i++){
		printf("Informe a nota do %dº aluno P1.\n", i);
		scanf("%f", &vetp1[i]);
		printf("Informe a nota do %dº aluno P2.\n", i);
		scanf("%f", &vetp2[i]);
		media[i] = (vetp1[i]+vetp2[i])/2;
	}
		for (i=1; i<=n; i++){
			printf("A nota da P1 do %dº aluno eh %.1f\n", i, vetp1[i]);
			printf("A nota da P2 do %dº aluno eh %.1f\n", i, vetp2[i]);
			printf("A media do %dº aluno eh %.1f\n\n", i, media[i]);
		}
		
	return 0;
}