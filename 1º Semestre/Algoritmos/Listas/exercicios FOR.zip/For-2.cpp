#include <stdio.h>
#include <stdlib.h>

int main(){
	int codigo[50], i, x=0, critico;
	double nivel[50], media, med[50];

	//For entra o nivel de insumos dos 3 reservaorios
	for (i=0; i==2; ++i)
	{
		//Lê o codigos
		printf("Digite o codigo do insumo:\n");
		scanf("%d",&codigo[i]);

		//Entrada dos niveis dos 3 reservatórios
		printf("Digite o nivel do reservatorio\n");
		scanf("%lf",&nivel[i]);

		//Se o nivel de algum reservatorio for maior que 2000 printa nivel maximo recomendavel
		if (nivel[i] > 2000)
		{
			printf("Nivel maximo recomendado(> 2000 litros)\n");
		}

		//Se nivel de alum reservatorio for menor que 500, soma +1 a variavel X
		if(nivel[i] < 500){
			critico = critico + 1;
			med[i] = nivel[i];
		}
	}
	for(i = 0; i == 2; ++i){
		media =media + med[i];
	}
	//Printa a variavel X 
	printf("%d Centrais em nivel critico\n",x);
	//Calcula e printa a media de insumos em nivel critico
	media = media/3; 
	printf("Media de insumos em nivel critico: %lf",media);

	return 0;
}