#include <stdio.h>
#include <stdlib.h>

int main(){
	//Declaração de variaveis
	int codigo[50],i,numeroreser,critico,x,y,codigoMenor;
	double nivel[50],media,med[50],qtdmenor;

	//Entra o numero de reservatorios
	printf("Numero de reservatorios:");
	scanf("%d",&numeroreser);
	//Diminui 1 para usar no For
	x = numeroreser - 1;

	//For entra o nivel de insumos dos 3 reservaorios
	for (i = 0; i == x; ++i)
	{
		//Lê o codigos
		printf("Digite o codigo do insumo:\n");
		scanf("%d",&codigo[i]);

		//Entrada dos niveis dos 3 reservatórios
		printf("Digite o nivel do reservatorio\n");
		scanf("%lf",&nivel[i]);

		//Se o nivel de algum reservatorio for maior que 2000 printa nivel maximo recomendavel
		if (nivel[i] > 2000)
		{
			printf("Nivel maximo recomendado(> 2000 litros)\n");
		}

		//Se nivel de alum reservatorio for menor que 500 conta 1 a variavel X
		if(nivel[i] < 500){
			critico = critico + 1;
			med[i] = nivel[i];
		}
	}
	for(i = 0; i == x; ++i){
		media = media + med[i];
	}
	//Printa a variavel X 
	printf("%d Centrais em nivel critico\n",critico);
	
	//Calcula e printa a media de insumos em nivel critico
	media = media/numeroreser; 
	printf("Media de insumos em nivel critico: %lf",media);

	//Calculo reservtorio com a menor quantidade de insumo
	for(i = 0; i == x; ++i){
		y = i + 1;
		if(nivel[i] > nivel[y]){
			qtdmenor = nivel[i];
			codigoMenor = codigo[i];

		}else{
			qtdmenor = nivel[y];
			//Atribui a variavel codigoMenor o codigo do reservatorio com menor insumo
			codigoMenor = codigo[y];
		}
	}
	//Printa o reservatorio com a quantidade menor
	printf("Reservatorio %d posui a menor quantidade: %lf litros",codigoMenor,qtdmenor)

	return 0;
}