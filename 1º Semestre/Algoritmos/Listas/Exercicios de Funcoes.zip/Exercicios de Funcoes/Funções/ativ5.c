/*Leonardo Werlang				Algortimos: Turma A
Um estacionamento cobra uma taxa mínima de R$2,00 para estacionar por três horas. Um adicional
de R$0,50 por hora não necessariamente inteira é cobrado após as três primeiras horas. O valor
máximo para qualquer dado período de 24 horas é R$10,00. Suponha que nenhum carro fica
estacionado por mais de 24 horas por vez. Escreva um aplicativo que calcule e exiba as taxas do
estacionamento para cada cliente que estacionou nessa garagem ontem. Você deve inserir as horas de
estacionamento para cada cliente. O programa deve exibir a cobrança para o cliente atual e calcular e
exibir o total recebido no final do dia. O programa deve usar uma função valorAPagar para
determinar a cobrança para cada cliente.
*/

#include <stdio.h>

double valorAPagar(double valor){
	if(valor <= 3){
		valor = 2;
	}else{
		valor = valor - 3;
		valor = (valor * 0.5) + 2;
	}
	if(valor > 10){
		valor = 10;
	}
	return valor;
}

int main(){
	double tempo, cont=0, total=0;
	while(cont < 24){
		printf("Digite o tempo: ");
		scanf("%lf", &tempo);
		cont+=tempo;
		printf("O valor a pagar eh R$: %.2lf\n", valorAPagar(tempo));
		total+= valorAPagar(tempo);
	}
	printf("\nO total recebido no dia eh R$ %.2lf\n", total);
	return 0;
}