#include <stdio.h>
#include <stdlib.h>
int fatorial(int n){
	int i;
	long long int cont=1;
	for (i=n; i>0; i--){
		cont*= i;
	}
	return cont;
}
int main(){
	int n;
	printf("Informe um numero para ser fatorado.\n");
	scanf("%d", &n);
	if (n>=0){
		printf("Fatorial de %d eh %lld\n", n, (long long int) fatorial(n));
	}
	return 0;
}