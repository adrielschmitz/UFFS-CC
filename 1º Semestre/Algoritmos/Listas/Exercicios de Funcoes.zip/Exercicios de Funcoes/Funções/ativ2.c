#include <stdio.h>
#include <stdlib.h>
float minimo(float a, float b, float c){
	float m;	
	if(a<b && a<c)
		m = a;
	else if(b<a && b<c)
		m = b;
	else
		m = c;
 return m;
}

int main(){
	float a, b, c, min;
	printf("Informe valores para A, B e C\n");
	scanf("%f %f %f", &a, &b, &c);
	printf("Menor número informado eh = %.1f\n", min = minimo(a, b, c));

	return 0;
}