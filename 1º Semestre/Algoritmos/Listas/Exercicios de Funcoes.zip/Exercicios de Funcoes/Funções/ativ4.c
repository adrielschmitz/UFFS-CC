#include <stdio.h>
#include <stdlib.h>
char vogal(char x){
	if(x=='a'||x=='e'||x=='i'||x=='o'||x=='u'){
		return 1;
	} else {
		return 0;
	}
}
int main(){
	char x;
	printf("Informe uma letra\n");
	scanf ("%c", &x);
	if (vogal(x)){
		printf("'%c' eh vogal.\n", x);
	} else {
		printf("'%c' nao eh vogal.\n", x);
	}

	return 0;
}