#include <stdio.h>
#include <stdlib.h>

float volume(float r){
	float pi=3.14, v = (4/3)*(pi*r);
	
	return v;
}
int main(){
	float r;
	printf("Informe o valor do raio.\n");
	scanf ("%f", &r);
	float resultado = volume(r);
	printf("Volume da esfera = %.2f\n", resultado);

	return 0;
} 