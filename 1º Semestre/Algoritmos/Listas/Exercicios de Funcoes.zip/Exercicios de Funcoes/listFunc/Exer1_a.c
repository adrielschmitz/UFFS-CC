#include <stdio.h>

#define MAX 100

int primo(int n){
	int i, j, cont, vet[MAX];
	for(i=2; i<MAX; i++){
		cont =0;
		for(j=2; j<i; j++){
			if(i % j == 0){
				cont++;
			}
		}
		if(!cont){
			vet[i] = 1;
		}else{
			vet[i] = 0;
		}
	}
	if(vet[n]){
		return 1;
	}else{
		return 0;
	}
}

int main(){
	int a, b, i;
	scanf("%d %d", &a, &b);
	for(i=a; i<=b; i++){
		if(primo(i)){
			printf("%d ", i);
		}
	}
	printf("\n");
	return 0;
}