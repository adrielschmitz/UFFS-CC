#include <stdio.h>
#include <string.h>

void encaixa(char n1[], char n2[]){
	int tamN1, tamN2, cont, i ,j, contp = 0;
	tamN1 = strlen(n1) - 1;
	tamN2 = strlen(n2) - 1;
	if(tamN1 > tamN2){
		for(i=0; i<tamN1; i++){
			if(n1[i] == n2[0]){
				cont = 0;
				for(j=0; j<=tamN2; j++){
					if(n1[i+j] == n2[j]){
						cont++;
					}
				}
				if(cont == tamN2+1){
					printf("b é segmento de a\n");
					contp++;
					break;
				}
			}
		}
	}else{
	for(i=0; i<tamN2; i++){
			if(n2[i] == n1[0]){
				cont = 0;
				for(j=0; j<=tamN1; j++){
					if(n2[i+j] == n1[j]){
						cont++;
					}
				}
				if(cont == tamN1+1){
					printf("a é segmento de b\n");
					contp++;
					break;
				}
			}
		}
	}
	if(!contp){
		printf("um não é segmento do outro\n");
	}
}

int main(){
	int n,  i;
	char n1[10], n2[10];
	printf("Digite a quantidade de casos de teste: ");
	scanf("%d", &n);
	for(i=0; i<n; i++){
		scanf("%s %s", n1, n2);
		encaixa(n1, n2);
	}
	return 0;
}