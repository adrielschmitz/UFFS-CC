#include <stdio.h>

int tempo(int h1, int m1, int h2, int m2){
	int min1, min2, min;
	min1 = (h1 * 60) + m1;
	min2 = (h2 * 60) + m2;
	if(min2 < min1){
		min2 += 1440;
	}
	min = min2 - min1;
	return min;
}

int main(){
	int h1, m1, h2, m2;
	while(scanf("%d %d %d %d", &h1, &m1, &h2, &m2), h1 != 0 || m1 != 0 || h2 != 0 || m2 != 0){
		printf("%d\n", tempo(h1, m1, h2, m2));
	}
	return 0;
}