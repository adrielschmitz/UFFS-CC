#include <stdio.h>
#include <string.h>
#include <math.h>

int mdc(int n1, int n2){
	int resto = 1;
	while(resto){
		resto = n1 % n2;
		n1 = n2;
		n2 = resto;
	}
	return n1;
}

int converte(char num[]){
	int i, soma = 0, expoente = 0, tam;
	tam = strlen(num) - 1;
	for(i=tam; i>=0; i--){
		if(num[i] == '1'){
			soma += pow(2, expoente);
		}
		expoente++;
	}
	return soma;
}

int main(){
	int n, i, x, n1, n2;
	char str1[10000], str2[10000];
	scanf("%d", &n);
	for(i=0; i<n; i++){
		scanf("%s %s", str1, str2);
		n1 = converte(str1);
		n2 = converte(str2);
		x = mdc(n1, n2);
		if(x > 1){
			printf("Pair #%d: All you need is love!\n", i+1);
		}else{
			printf("Pair #%d: Love is not all you need!\n", i+1);
		}
	}
	return 0;
}