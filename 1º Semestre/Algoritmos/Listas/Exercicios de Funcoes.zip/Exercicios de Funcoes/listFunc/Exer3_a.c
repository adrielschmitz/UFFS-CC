#include <stdio.h>

int main(){
	int i, cont[10];
	char num[10];
	for(i=0; i<10; i++){
		cont[i] = 0;
	}
	scanf("%s", num);
	for(i=0; i<10; i++){
		if(num[i] == '1'){
			cont[0]++;
		}else if(num[i] == '2'){
			cont[1]++;
		}else if(num[i] == '3'){
			cont[2]++;
		}else if(num[i] == '4'){
			cont[3]++;
		}else if(num[i] == '5'){
			cont[4]++;
		}else if(num[i] == '6'){
			cont[5]++;
		}else if(num[i] == '7'){
			cont[6]++;
		}else if(num[i] == '8'){
			cont[7]++;
		}else if(num[i] == '9'){
			cont[8]++;
		}
	}
	for(i=0; i<10; i++){
		if(cont[i] != 0){
			printf("O numero %d aparece %d vezes\n", i+1, cont[i]);
		}
	}	
	return 0;
}