#include <stdio.h>

int mdc(int n1, int n2){
	int resto =1;
	while(resto != 0){
		resto = n1 % n2;
		n1 = n2;
		n2 = resto;
	}
	if(n1 == 1){
		return 1;
	}else{
		return 0;
	}
}

int main(){
	int n1, n2, n3, aux;
	while(scanf("%d %d %d", &n1, &n2, &n3) != EOF){
		if(n3 > n2){
			aux = n2;
			n2 = n3;
			n3 = aux;
		}
		if(n2 > n1){
			aux = n1;
			n1 = n2;
			n2 = aux;
		}
		if(n1 * n1 == (n2 * n2)+(n3 * n3)){
			if(mdc(n1, n2) == 1){
				if(mdc(n1, n3) == 1){
					printf("tripla pitagorica primitiva\n");
				}else{
					printf("tripla pitagorica\n");
				}
			}else{
				printf("tripla pitagorica\n");
			}
		}else{
			printf("tripla\n");
		}
	}
	return 0;
}