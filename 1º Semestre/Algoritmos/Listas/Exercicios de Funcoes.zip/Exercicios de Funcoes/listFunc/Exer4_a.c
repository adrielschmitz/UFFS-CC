#include <stdio.h>
#include <string.h>

void encaixa(int n1, int n2){
	int verifica = 1;
	if(n1 >= n2){
		while(n1 != 0 && n2 != 0){
			if(n1%10 != n2%10){
				verifica = 0;
				break;
			}else{
				n1 = n1 / 10;
				n2 = n2 / 10;
			}
		}
		if(verifica){
			printf("encaixa\n");
		}else{
			printf("nao encaixa\n");
		}
	}else{
		printf("nao encaixa\n");
	}
}

int main(){
	int n, n1, n2, i;
	printf("Digite a quantidade de casos de teste: ");
	scanf("%d", &n);
	for(i=0; i<n; i++){
		scanf("%d %d", &n1, &n2);
		encaixa(n1, n2);
	}
	return 0;
}