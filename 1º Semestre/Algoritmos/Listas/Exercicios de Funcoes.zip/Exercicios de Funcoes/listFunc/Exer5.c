#include <stdio.h>

void mdc(int n1, int n2){
	int resto = 1;
	while(resto != 0){
		resto = n1 % n2;
		n1 = n2;
		n2 = resto;
	}
	printf("%d\n", n1);
}

int main(){
	int n1, n2;
	scanf("%d %d", &n1, &n2);
	mdc(n1, n2);
	return 0;
}