#include <stdio.h>

int main(){
	int i, cont[10], cont2[10], verifica = 1;
	char num[100], num2[100];
	for(i=0; i<100; i++){
		cont[i] = 0;
		cont2[i] = 0;
	}
	scanf("%s", num);
	scanf("%s", num2);
	for(i=0; i<100; i++){
		if(num[i] == '1'){
			cont[0]++;
		}else if(num[i] == '2'){
			cont[1]++;
		}else if(num[i] == '3'){
			cont[2]++;
		}else if(num[i] == '4'){
			cont[3]++;
		}else if(num[i] == '5'){
			cont[4]++;
		}else if(num[i] == '6'){
			cont[5]++;
		}else if(num[i] == '7'){
			cont[6]++;
		}else if(num[i] == '8'){
			cont[7]++;
		}else if(num[i] == '9'){
			cont[8]++;
		}
		if(num2[i] == '1'){
			cont2[0]++;
		}else if(num2[i] == '2'){
			cont2[1]++;
		}else if(num2[i] == '3'){
			cont2[2]++;
		}else if(num2[i] == '4'){
			cont2[3]++;
		}else if(num2[i] == '5'){
			cont2[4]++;
		}else if(num2[i] == '6'){
			cont2[5]++;
		}else if(num2[i] == '7'){
			cont2[6]++;
		}else if(num2[i] == '8'){
			cont2[7]++;
		}else if(num2[i] == '9'){
			cont2[8]++;
		}
	}
	for(i=0; i<10; i++){
		if(cont[i] != cont2[i]){
			verifica = 0;
			break;
		}
	}
	if(verifica){
		printf("%s eh uma permutação de %s\n", num2, num);
	}else{
		printf("%s não eh uma permutação de %s\n", num2, num);
	}
	return 0;
}