#include <stdio.h>
#include <stdlib.h>

int main(){
	int numerador, denominador;
	float divisao, x;
	numerador = 1;
	denominador = 1;
	x = 0;

	while (numerador<=99) {
		divisao =(float) numerador/denominador;
		x += divisao;
		numerador+=2;
		denominador++;
	}
	printf ("O resultado do calculo eh \n%.2lf\n", x);

	return 0;
}