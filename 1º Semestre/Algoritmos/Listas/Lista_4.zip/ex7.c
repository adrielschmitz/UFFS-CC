#include <stdio.h>
#include <stdlib.h>

int main() {
	int idade, numLivros, qtdadeTerceira=0, maiorQtdade=-1, qtdadeNaoTerceira=0, numAlunos=0, serie, resposta;
	printf ("Informe sua idade:\n");
	scanf ("%d", &idade);
	while (idade!=0) {
		numAlunos++;
		printf ("Informe sua serie(1,2,3 ou 4):\n");
		scanf ("%d", &serie);
		printf ("Quantos livros voce le por mes?\n");
		scanf ("%d", &numLivros);
		printf ("Vc gosta de redacao (Sim-1) ou (Não=0)?\n");
		scanf ("%d", &resposta);
		if (serie==3) {
			qtdadeTerceira++;
		}
		if (numLivros>maiorQtdade && serie==4) {
			maiorQtdade=numLivros;
		}
		if (resposta==0 && serie==3) {
			qtdadeNaoTerceira++;
			printf ("\nInforme sua idade:\n");
			scanf ("%d", &idade);
		}
	} 
	if (numAlunos>0) {
		printf ("A quantidade de alunos que estah na terceira serie eh de %d\n", qtdadeTerceira);
		printf ("A maior quantidade de livros lidos por um aluno que estah na quarta serie eh de %d\n", maiorQtdade);
		printf ("A porcentagem de alunos que nao gostam de fazer redacao e que estao na terceira serie eh de %.2f\n",(float)qtdadeNaoTerceira*100/numAlunos);
	}
	else {
		printf ("Nenhum aluno respondeu a pesquisa!\n");
	}
	return 0;
}