#include <stdio.h>

int main(){

	int entrada;
	float media, soma = 0, aux2 = 0;
	printf ("Digite um numero inteiro (negativo para parar)\n");
	scanf ("%d", &entrada);

	while (entrada>0) {
		soma += entrada;
		aux2++;
			printf ("Informe um numero inteiro\n");
			scanf ("%d", &entrada);
	} 
		if (aux2>0) {
			media = (float)soma/aux2;
			printf ("A media calculada eh = %.1lf\n", media);
		} 	else { 
				printf ("Nenhum valor positivo foi informado\n");
			}

	return 0;
}