#include <stdio.h>
#include <stdlib.h>

int main(){
	
	int i=0, codigo, dependentes=0; 
	double horas=0, salario=0, inss=0, ir=0, salarioliquido;
	
	while ( i<10 ) {
		printf ("Informe o codigo\n");
		scanf ("%d", &codigo);
		printf ("Informe as horas trabalhadas\n");
		scanf ("%lf", &horas);
		printf ("Informe o numero de dependentes\n");
		scanf ("%d", &dependentes);
			salario = (horas*12)+(40*dependentes);
			inss = (salario*8.5)/100;
			ir = (salario*5)/100; 
			salarioliquido = salario-inss-ir;
		printf ("O funcioário portador do código %d teve R$ %.2lf de desconto do INSS e R$ %.2lf de IR\n", codigo, inss, ir);
		printf ("Seu salario liquido eh R$ %.2lf\n", salarioliquido);
		
		i++;
	} 

	return 0;
}