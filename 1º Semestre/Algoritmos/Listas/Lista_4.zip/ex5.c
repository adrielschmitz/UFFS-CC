#include <stdio.h>
#include <stdlib.h>
#include <string.h> // para usar função strcmp;
#include <ctype.h> 

int main(){

	char sexo, 
	int idade, qtdlivro=0, livrosmenor10=0, mulheresmais5=0, somahomens=0;
	int  naoleram=0, numpessoas=0, contahomem;
	float percnaoleram; 

	printf ("Informe sua Idade\n");
	scanf ("%d", &idade);

	while (idade>=0) {
		numpessoas++;
		printf("Informe seu sexo: (F) ou (M)\n");
		scanf ("%c", &sexo);
		printf("Informe a quantidade de livros que leu em 2006:\n");
		scanf ("%d", &qtdlivro);
		if (idade<10) {
			livrosmenor10+=qtdlivro;
		}
		if (sexo=='F' && qtdlivro>=5) {
			mulheresmais5++;
		}
		if (sexo=='M' && qtdlivro<5) {
			somahomens+=idade;
			contahomem++;
		}
		if (qtdlivro==0) {
			naoleram++;
			printf("Informe sua idade: \n");
			scanf ("%d", &idade);
		}
	}
	if (numpessoas>0) {
		printf ("A quantidade tatal de livros lidos pelos entrevistado menos que 10 anos foi de %d\n", livrosmenor10);
		printf ("A quantidade de mulheres que leram 5 livros ou mais foi de %d\n", mulheresmais5);
	
		if (contahomem>0) {
			printf ("A media de idade dos homens que leram menos que 5 livros foi de %.2lf\n", (float)somahomens/contahomem);
		}	else { 
				printf ("Nenhum homem que participou da pesquisa leu menos de 5 livros\n");
			}
		printf ("O percentual de pessoas que nao leram livros foi de %.2lf\n", (float)(naoleram*100)/numpessoas);

	}
	else {
		printf ("Nenhuma pessoa informou dados para a pesquisa!\n");
	}

	return 0;
}