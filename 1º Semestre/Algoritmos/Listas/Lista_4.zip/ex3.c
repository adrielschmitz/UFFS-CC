#include <stdio.h>
#include <stdlib.h>

int main(){

	int vet[10], impar=0, par=0, i; 
	double soma, aux, media;
	
		for (i=0 ; i<10 ; i++) {
			scanf ("%d", &vet[i]);
			
			if (vet[i]%2 != 0) {
				impar++;
				aux += vet[i];
				media = aux/impar;
			} 
			else {
				par++;
				soma += vet[i];
			}
		}
		
		printf ("Numeros impares lidos = %d\n", impar);
		printf ("Media dos numeros impares = %.1lf\n", media);
		printf ("Numeros pares lidos = %d\n", par);
		printf ("Soma dos numeros pares = %.1lf\n", soma);
		

	return 0;
}