#include <stdio.h>
#include <stdlib.h>

int main(){
	int idade, aux, qtdadeOpiniaoBoa=0, somaIdade=0, qtdadeOpiniaoRuim=0;int ID, opiniao, IDMaisVelha, NUMPESSOAS, idadeMaisVelha=-1;
	float mediaIdade, percentual;
	printf ("Informe o numero de pessoas\n");
	scanf ("%d", &NUMPESSOAS);

		for (aux=0;aux<NUMPESSOAS;aux++) {
			printf ("Informe a sua idade: ");
			scanf ("%d", &idade);
			printf ("Informe o seu ID: ");
			scanf ("%d", &ID);
			printf ("Informe a sua opiniao(0-10): ");
			scanf ("%d", &opiniao);
			if (opiniao==10) {
				qtdadeOpiniaoBoa++;
				somaIdade=somaIdade+idade;
			}
			if (opiniao<=5) {
				qtdadeOpiniaoRuim++;
			}
			if (idade>idadeMaisVelha) {
				idadeMaisVelha=idade;
				IDMaisVelha=ID;
			}
		}
	printf ("\nA quantidade de respostas 10 foi de %d", qtdadeOpiniaoBoa);
		mediaIdade=(float)somaIdade/NUMPESSOAS;
	printf ("\nA média de idade das pessoas que responderam o questionário foi de %.2f", mediaIdade);
		percentual=(float)qtdadeOpiniaoRuim*100/NUMPESSOAS;
	printf ("\nA porcentagem de pessoas que responderam 5 ou menos foi de %.2f", percentual);
	printf ("\nO ID da pessoa mais velha eh %d\n", IDMaisVelha);

	return 0;
}