#include <stdio.h>

	int main(){
	double altura, pesoideal;
	char sexo;
	scanf ("%c", &sexo);
	scanf ("%lf", &altura);

	if (sexo == 'H'){
		pesoideal = 72.7*altura-58;
		printf (" Peso ideal para homens = %.2lf\n", pesoideal);
	}

	else {
		pesoideal = 62.1*altura-44,7;
		printf ("Peso ideal para mulheres = %.2lf\n", pesoideal);
		}
		return 0;

	}