#include <stdio.h>

	int main(){
	double nota1, nota2, freq, media; 
	int aulasministradas, aulasassistidas;

	scanf ("%lf %lf", &nota1, &nota2);
	scanf ("%d %d", &aulasministradas, &aulasassistidas);

	media = (nota1+nota2)/2;
	freq = ((aulasassistidas*100)/aulasministradas);

	if (media > 6 && freq >= 75) {
		printf ("Aprovado!\n");
	}
	else {
		printf ("Reprovado!\n");
	}

	return 0;




	}