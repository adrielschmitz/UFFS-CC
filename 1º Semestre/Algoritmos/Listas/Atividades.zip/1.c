#include <stdio.h>
	
	int main(){
	int A, B;
	scanf("%d",&A);
	scanf("%d",&B);

	if (A>B) {
		A=A-B;
		printf ("A: %d\n", A);
	}
	else {
		B=B-A;
		printf ("B: %d\n", B);
	}

	return 0;


	}