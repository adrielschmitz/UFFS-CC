#include <stdio.h>
#include <stdlib.h>
#include <math.h>

	int main (){
	int numero1, numero2, numero3;
	scanf ("%d %d %d", &numero1, &numero2, &numero3);

	if (numero1 >= 0) {
		printf ("Raiz quadrada: %.2lf\n", sqrt(numero1));
	}
	else {
		printf ("Quadrado: %.2d\n", numero1*numero1);
	}
	if (numero2>10 && numero2<100) {
		printf ("Número está entre 10 e 100 - intervalo permitido\n");

	}
	if (numero3<numero2) {
		printf ("%d\n", numero2-numero3);
	}
	else {
		printf ("%d\n", numero3+1);
	}
	return 0;



	}