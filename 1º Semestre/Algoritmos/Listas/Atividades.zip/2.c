#include <stdio.h>

	int main(){

	int numero, resto;
	scanf("%d", &numero);
	resto = numero%2;
	if (resto==0) {
		printf ("Numero par!\n");
		}
	else {
		printf ("Numero Impar!\n");

	}
return 0;









	}