#include <stdio.h>
	int main(){
	int numero1, numero2;
	printf ("Digite um número: ");
	scanf ("%d",&numero1);
	printf ("Digite o segundo número: ");
	scanf ("%d",&numero2);

		if (numero1==numero2) {
		printf ("Numeros iguais!\n");
		}
		else if (numero1>numero2) {
		printf ("%d É o maior!\n", numero1);
		}
		else if (numero1<numero2) {
		printf ("%d É o maior\n");
		}
 return 0;


	}