package controle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ConexaoBD {
    public Statement stm;
    public static Connection conexao = null;
    public static String caminho = (System.getProperty("user.dir") + "\\banco\\db_projeto.db");
    public ResultSet rs;
            
    public static Connection conexao(){
        try{
            Class.forName("org.sqlite.JDBC");
            conexao = DriverManager.getConnection("jdbc:sqlite:" + caminho);
            //JOptionPane.showMessageDialog(null, "Conectado ao banco de dados!");
            return conexao;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Falha ao conectar com o Banco de Dados\n" + e.getMessage());
            return null;
        }
    }
    public void desconecta(){
        try{
            conexao.close();
            //JOptionPane.showMessageDialog(null, "Desconectado do banco de dados!");         
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Falha ao desconectar com o Banco de Dados\n" + e);
        }
    }
    
    public void executaSql(String sql){
        try {
            stm = conexao.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro executa SQL:" + ex);
        }
    }
}
