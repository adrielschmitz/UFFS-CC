
package controle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.ModeloCliente;
import modelo.ModeloVeiculo;

public class ControleVeiculos {
    Connection conectar = null;
    PreparedStatement pst = null;
    ResultSet rst = null;
    
    ModeloVeiculo carros = new ModeloVeiculo();
    
    public boolean salvar(ModeloVeiculo carros){
        try{
            conectar = ConexaoBD.conexao();
            pst = conectar.prepareStatement("insert into veiculo(renavam, n_chassi, placa,"
                                            + "modelo, fabricante, ano, km, tipo, "
                                            + "cor, preco, detalhes) values(?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, carros.getRenavam());
            pst.setString(2, carros.getnChassi());
            pst.setString(3, carros.getPlaca());
            pst.setString(4, carros.getModelo());
            pst.setString(5, carros.getFabricante());
            pst.setString(6, carros.getAnoVeiculo());
            pst.setString(7, carros.getKm());
            pst.setString(8, carros.getTipo());
            pst.setString(9, carros.getCor());
            pst.setString(10, carros.getPreco());
            pst.setString(11, carros.getDetalhes());
                       
            pst.execute();
            
            pst.close();
            conectar.close();
            JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso!");
            return true;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Falha ao inserir os dados do veiculo no Banco de Dados:" + e);
            return false;
        }
    }
}
