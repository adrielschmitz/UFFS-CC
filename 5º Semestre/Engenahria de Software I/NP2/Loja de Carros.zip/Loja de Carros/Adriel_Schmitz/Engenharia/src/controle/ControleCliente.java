package controle;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.Statement;
import modelo.ModeloCliente;

public class ControleCliente{
    Connection conectar = null;
    PreparedStatement pst = null;
    ResultSet rst = null;
    
    ModeloCliente cliente = new ModeloCliente();
    
    public boolean salvar(ModeloCliente cliente){
        try{
            conectar = ConexaoBD.conexao();
            pst = conectar.prepareStatement("insert into cliente(nome, dataNascimento, "
                                            + "cpf, rg, orgaoExpeditor, estadoEmissor, ddd, "
                                            + "telefone, celular, email, rua, complemento, "
                                            + "bairro, cidade, estado, cep, detalhes) "
                                            + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, cliente.getNome());
            pst.setString(2, cliente.getDataNascimento());
            pst.setString(3, cliente.getCpf());
            pst.setString(4, cliente.getRg());
            pst.setString(5, cliente.getOrgaoExpeditor());
            pst.setString(6, cliente.getEstadoEmissor());
            pst.setString(7, cliente.getDdd());
            pst.setString(8, cliente.getTelefone());
            pst.setString(9, cliente.getCelular());
            pst.setString(10, cliente.getEmail());
            pst.setString(11, cliente.getRua());
            pst.setString(12, cliente.getComplemento());
            pst.setString(13, cliente.getBairro());
            pst.setString(14, cliente.getCidade());
            pst.setString(15, cliente.getEstado());
            pst.setString(16, cliente.getCep());
            pst.setString(17, cliente.getDetalhes());
            
            pst.execute();
            
            pst.close();
            conectar.close();
            JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso!\n");
            return true;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "Falha ao inserir os dados do cliente no Banco de Dados:" + e);
            return false;
        }
    }
    /*public ModeloCliente pesquisar(ModeloCliente mod){
        conectar = ConexaoBD.conexao();
        conectar.executaSql("select from where cpf like'%"+mod.getPesquisa()+"%'" );
        conectar.close();
        return mod;
        
    }*/
}
