/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.*;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class CriarPopularDB {
    Connection conectar = null;
    PreparedStatement pst = null;
    
    public void criarTabelas(){
        conectar = ConexaoBD.conexao();
        try{
            pst = conectar.prepareStatement("CREATE TABLE IF NOT EXISTS cliente (nome varchar (40) NOT NULL, dataNascimento varchar (40) NOT NULL, cpf varchar (10) NOT NULL PRIMARY KEY, rg varchar (20) NOT NULL, orgaoExpeditor varchar (40) NOT NULL, estadoEmissor varchar (40) NOT NULL, ddd varchar (4) NOT NULL, telefone varchar (20), celular varchar (20) NOT NULL, email varchar (40), rua varchar (40) NOT NULL, complemento varchar (40), bairro varchar (40) NOT NULL, cidade varchar (40) NOT NULL, estado varchar (40) NOT NULL, cep varchar (40), detalhes varchar (40))");
            pst.execute();
            pst = conectar.prepareStatement("CREATE TABLE IF NOT EXISTS veiculo(\n" +
                    "renavam varchar(40) NOT NULL,\n" +
                    "n_chassi varchar(40) NOT NULL,\n" +
                    "placa varchar(40) NOT NULL PRIMARY KEY,\n" +
                    "modelo varchar(40),\n" +
                    "fabricante varchar(40) NOT NULL,\n" +
                    "ano varchar(40) NOT NULL,\n" +
                    "km varchar(40) NOT NULL,\n" +
                    "tipo varchar(40),\n" +
                    "cor varchar(40) NOT NULL,\n" +
                    "preco varchar(40) NOT NULL,\n" +
                    "detalhes varchar NOT NULL\n" +
                    ")");
            pst.execute();
            pst.close();
            conectar.close();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Falha ao conectar com o Banco de Dados\n" + e.getMessage());
        }
    }
}
