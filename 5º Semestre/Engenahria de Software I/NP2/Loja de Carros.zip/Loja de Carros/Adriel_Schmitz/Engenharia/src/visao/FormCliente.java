/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;
import controle.ControleCliente;
import java.sql.Connection;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import modelo.ModeloCliente;

public class FormCliente extends javax.swing.JFrame {
    ModeloCliente modelo = new ModeloCliente();
    Connection conectar = null;
    ControleCliente controle = new ControleCliente();
    
    public FormCliente(){
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabelNomeCompleto = new javax.swing.JLabel();
        jLabelDataNascimento = new javax.swing.JLabel();
        jLabelCpf = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jPanelTipoPessoa = new javax.swing.JPanel();
        jRadioButtonPessoaFisica = new javax.swing.JRadioButton();
        jRadioButtonPessoaJuridica = new javax.swing.JRadioButton();
        jTextFieldCpf = new javax.swing.JTextField();
        jLabelRg = new javax.swing.JLabel();
        jTextFieldRg = new javax.swing.JTextField();
        jLabelEstadoEmissor = new javax.swing.JLabel();
        jComboBoxEstadoEmissor = new javax.swing.JComboBox<>();
        jLabelRua = new javax.swing.JLabel();
        jTextFieldRua = new javax.swing.JTextField();
        jLabelBairro = new javax.swing.JLabel();
        jTextFieldBairro = new javax.swing.JTextField();
        jLabelCidade = new javax.swing.JLabel();
        jTextFieldCidade = new javax.swing.JTextField();
        jLabelEstado = new javax.swing.JLabel();
        jComboBoxEstado = new javax.swing.JComboBox<>();
        jLabelCep = new javax.swing.JLabel();
        jTextFieldCep = new javax.swing.JTextField();
        jLabelDdd = new javax.swing.JLabel();
        jTextFieldDdd = new javax.swing.JTextField();
        jLabelTelefone = new javax.swing.JLabel();
        jLabelCelular = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jTextFieldTelefone = new javax.swing.JTextField();
        jTextFieldCelular = new javax.swing.JTextField();
        jTextFieldEmail = new javax.swing.JTextField();
        jScrollPaneDetalhes = new javax.swing.JScrollPane();
        jTextAreaDetalhes = new javax.swing.JTextArea();
        jLabelDetalhes = new javax.swing.JLabel();
        jButtonCancelar = new javax.swing.JButton();
        jButtonCadastrarVeiculo = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jLabelComplemento = new javax.swing.JLabel();
        jTextFieldComplemento = new javax.swing.JTextField();
        jLabelOrgaoExpeditor = new javax.swing.JLabel();
        jTextFieldOrgaoExpeditor = new javax.swing.JTextField();
        jDateChooserDataNascimento = new com.toedter.calendar.JDateChooser();
        jLabelTituloFormularioClientes = new javax.swing.JLabel();
        jLabelFundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(500, 500));
        setPreferredSize(new java.awt.Dimension(500, 500));
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setToolTipText("");
        jPanel1.setLayout(null);

        jLabelNomeCompleto.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelNomeCompleto.setText("Nome Completo");
        jPanel1.add(jLabelNomeCompleto);
        jLabelNomeCompleto.setBounds(40, 60, 88, 15);

        jLabelDataNascimento.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelDataNascimento.setText("Data de Nascimento");
        jPanel1.add(jLabelDataNascimento);
        jLabelDataNascimento.setBounds(450, 60, 110, 15);

        jLabelCpf.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelCpf.setText("CPF");
        jPanel1.add(jLabelCpf);
        jLabelCpf.setBounds(40, 110, 20, 15);

        jTextFieldNome.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldNome.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextFieldNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldNomeActionPerformed(evt);
            }
        });
        jTextFieldNome.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldNomeKeyTyped(evt);
            }
        });
        jPanel1.add(jTextFieldNome);
        jTextFieldNome.setBounds(40, 80, 360, 25);

        jPanelTipoPessoa.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanelTipoPessoa.setLayout(null);

        buttonGroup1.add(jRadioButtonPessoaFisica);
        jRadioButtonPessoaFisica.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jRadioButtonPessoaFisica.setText("Pessoa Física");
        jRadioButtonPessoaFisica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanelTipoPessoa.add(jRadioButtonPessoaFisica);
        jRadioButtonPessoaFisica.setBounds(8, 3, 89, 20);

        buttonGroup1.add(jRadioButtonPessoaJuridica);
        jRadioButtonPessoaJuridica.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jRadioButtonPessoaJuridica.setText("Pessoa Jurídica");
        jRadioButtonPessoaJuridica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanelTipoPessoa.add(jRadioButtonPessoaJuridica);
        jRadioButtonPessoaJuridica.setBounds(120, 3, 99, 20);

        jPanel1.add(jPanelTipoPessoa);
        jPanelTipoPessoa.setBounds(40, 20, 220, 30);

        jTextFieldCpf.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldCpf.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldCpf);
        jTextFieldCpf.setBounds(40, 130, 120, 25);

        jLabelRg.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelRg.setText("RG");
        jPanel1.add(jLabelRg);
        jLabelRg.setBounds(180, 110, 27, 15);

        jTextFieldRg.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldRg.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldRg);
        jTextFieldRg.setBounds(180, 130, 110, 25);

        jLabelEstadoEmissor.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelEstadoEmissor.setText("Estado Emissor");
        jPanel1.add(jLabelEstadoEmissor);
        jLabelEstadoEmissor.setBounds(480, 110, 81, 15);

        jComboBoxEstadoEmissor.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jComboBoxEstadoEmissor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));
        jComboBoxEstadoEmissor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(jComboBoxEstadoEmissor);
        jComboBoxEstadoEmissor.setBounds(480, 130, 130, 25);

        jLabelRua.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelRua.setText("Rua");
        jPanel1.add(jLabelRua);
        jLabelRua.setBounds(40, 160, 20, 15);

        jTextFieldRua.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldRua.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextFieldRua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldRuaActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldRua);
        jTextFieldRua.setBounds(40, 180, 260, 25);

        jLabelBairro.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelBairro.setText("Bairro");
        jPanel1.add(jLabelBairro);
        jLabelBairro.setBounds(310, 160, 30, 15);

        jTextFieldBairro.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldBairro.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldBairro);
        jTextFieldBairro.setBounds(310, 180, 100, 25);

        jLabelCidade.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelCidade.setText("Cidade");
        jPanel1.add(jLabelCidade);
        jLabelCidade.setBounds(40, 220, 36, 15);

        jTextFieldCidade.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldCidade.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldCidade);
        jTextFieldCidade.setBounds(40, 240, 300, 25);

        jLabelEstado.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelEstado.setText("Estado");
        jPanel1.add(jLabelEstado);
        jLabelEstado.setBounds(370, 220, 37, 15);

        jComboBoxEstado.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));
        jComboBoxEstado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel1.add(jComboBoxEstado);
        jComboBoxEstado.setBounds(370, 240, 72, 25);

        jLabelCep.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelCep.setText("CEP");
        jPanel1.add(jLabelCep);
        jLabelCep.setBounds(480, 220, 21, 15);

        jTextFieldCep.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldCep.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldCep);
        jTextFieldCep.setBounds(477, 240, 130, 25);

        jLabelDdd.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelDdd.setText("DDD");
        jPanel1.add(jLabelDdd);
        jLabelDdd.setBounds(40, 280, 24, 15);

        jTextFieldDdd.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldDdd.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldDdd);
        jTextFieldDdd.setBounds(40, 300, 40, 25);

        jLabelTelefone.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelTelefone.setText("Telefone");
        jPanel1.add(jLabelTelefone);
        jLabelTelefone.setBounds(140, 280, 49, 15);

        jLabelCelular.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelCelular.setText("Celular");
        jPanel1.add(jLabelCelular);
        jLabelCelular.setBounds(270, 280, 35, 15);

        jLabelEmail.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelEmail.setText("E-mail");
        jPanel1.add(jLabelEmail);
        jLabelEmail.setBounds(410, 280, 31, 15);

        jTextFieldTelefone.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldTelefone.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldTelefone);
        jTextFieldTelefone.setBounds(140, 300, 99, 25);

        jTextFieldCelular.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldCelular.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldCelular);
        jTextFieldCelular.setBounds(270, 300, 110, 25);

        jTextFieldEmail.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldEmail.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldEmail);
        jTextFieldEmail.setBounds(410, 300, 193, 25);

        jTextAreaDetalhes.setColumns(20);
        jTextAreaDetalhes.setRows(5);
        jTextAreaDetalhes.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jScrollPaneDetalhes.setViewportView(jTextAreaDetalhes);

        jPanel1.add(jScrollPaneDetalhes);
        jScrollPaneDetalhes.setBounds(40, 360, 560, 57);

        jLabelDetalhes.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelDetalhes.setText("Detalhes");
        jPanel1.add(jLabelDetalhes);
        jLabelDetalhes.setBounds(40, 340, 47, 15);

        jButtonCancelar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.setToolTipText("Cancelar o cadastro do Cliente");
        jButtonCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelar);
        jButtonCancelar.setBounds(410, 440, 85, 30);

        jButtonCadastrarVeiculo.setText("Cadastrar Veículo");
        jButtonCadastrarVeiculo.setToolTipText("Salvar dados do Cliente e cadastrar Veículo");
        jButtonCadastrarVeiculo.setEnabled(false);
        jButtonCadastrarVeiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCadastrarVeiculoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCadastrarVeiculo);
        jButtonCadastrarVeiculo.setBounds(260, 440, 140, 30);

        jButtonSalvar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setToolTipText("Salvar os dados no banco de dados");
        jButtonSalvar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvar);
        jButtonSalvar.setBounds(500, 440, 85, 30);

        jLabelComplemento.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelComplemento.setText("Complemento");
        jPanel1.add(jLabelComplemento);
        jLabelComplemento.setBounds(420, 160, 80, 15);

        jTextFieldComplemento.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldComplemento.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldComplemento);
        jTextFieldComplemento.setBounds(420, 180, 190, 25);

        jLabelOrgaoExpeditor.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabelOrgaoExpeditor.setText("Órgão Expeditor");
        jPanel1.add(jLabelOrgaoExpeditor);
        jLabelOrgaoExpeditor.setBounds(310, 110, 90, 15);

        jTextFieldOrgaoExpeditor.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTextFieldOrgaoExpeditor.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jPanel1.add(jTextFieldOrgaoExpeditor);
        jTextFieldOrgaoExpeditor.setBounds(310, 130, 150, 25);

        jDateChooserDataNascimento.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(jDateChooserDataNascimento);
        jDateChooserDataNascimento.setBounds(448, 80, 160, 25);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(40, 50, 650, 480);

        jLabelTituloFormularioClientes.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelTituloFormularioClientes.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTituloFormularioClientes.setText("Cadastro de Clientes");
        getContentPane().add(jLabelTituloFormularioClientes);
        jLabelTituloFormularioClientes.setBounds(240, 10, 184, 22);

        jLabelFundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/fundotelaLogin.png"))); // NOI18N
        getContentPane().add(jLabelFundo);
        jLabelFundo.setBounds(0, 0, 730, 560);

        setSize(new java.awt.Dimension(745, 599));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldRuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldRuaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldRuaActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jTextFieldNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldNomeActionPerformed

        
    }//GEN-LAST:event_jTextFieldNomeActionPerformed
    
    private void insereBanco(){ // SETERS NO BANCO
        modelo.setNome(jTextFieldNome.getText());
        modelo.setDataNascimento(((JTextField)jDateChooserDataNascimento.getDateEditor().getUiComponent()).getText());
        modelo.setCpf(jTextFieldCpf.getText());
        modelo.setRg(jTextFieldRg.getText());
        modelo.setOrgaoExpeditor(jTextFieldOrgaoExpeditor.getText());
        modelo.setEstadoEmissor((String) jComboBoxEstadoEmissor.getSelectedItem());
        modelo.setRua(jTextFieldRua.getText());
        modelo.setComplemento(jTextFieldComplemento.getText());
        modelo.setBairro(jTextFieldBairro.getText());
        modelo.setCidade(jTextFieldCidade.getText());
        modelo.setEstado((String) jComboBoxEstado.getSelectedItem());
        modelo.setCep(jTextFieldCep.getText());
        modelo.setDdd(jTextFieldDdd.getText());
        modelo.setTelefone(jTextFieldTelefone.getText());
        modelo.setCelular(jTextFieldCelular.getText());
        modelo.setEmail(jTextFieldEmail.getText());
        modelo.setDetalhes(jTextAreaDetalhes.getText());
    }
    
    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        insereBanco();        
        if(controle.salvar(modelo)){
            dispose();
        }
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jTextFieldNomeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldNomeKeyTyped
        if(jTextFieldNome.getText().trim().isEmpty()){
            jButtonSalvar.setEnabled(false);
            jButtonCadastrarVeiculo.setEnabled(false);
        }else{
            jButtonSalvar.setEnabled(true);
            jButtonCadastrarVeiculo.setEnabled(true);
        }
    }//GEN-LAST:event_jTextFieldNomeKeyTyped
      
    private void jButtonCadastrarVeiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCadastrarVeiculoActionPerformed
        insereBanco(); 
        //Chama tela de Formulário de veículos
        if(controle.salvar(modelo)){
            dispose();
            FormVeiculos tela = new FormVeiculos();
            tela.setVisible(true);
        }

    }//GEN-LAST:event_jButtonCadastrarVeiculoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new FormCliente().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButtonCadastrarVeiculo;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jComboBoxEstado;
    private javax.swing.JComboBox<String> jComboBoxEstadoEmissor;
    private com.toedter.calendar.JDateChooser jDateChooserDataNascimento;
    private javax.swing.JLabel jLabelBairro;
    private javax.swing.JLabel jLabelCelular;
    private javax.swing.JLabel jLabelCep;
    private javax.swing.JLabel jLabelCidade;
    private javax.swing.JLabel jLabelComplemento;
    private javax.swing.JLabel jLabelCpf;
    private javax.swing.JLabel jLabelDataNascimento;
    private javax.swing.JLabel jLabelDdd;
    private javax.swing.JLabel jLabelDetalhes;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelEstado;
    private javax.swing.JLabel jLabelEstadoEmissor;
    private javax.swing.JLabel jLabelFundo;
    private javax.swing.JLabel jLabelNomeCompleto;
    private javax.swing.JLabel jLabelOrgaoExpeditor;
    private javax.swing.JLabel jLabelRg;
    private javax.swing.JLabel jLabelRua;
    private javax.swing.JLabel jLabelTelefone;
    private javax.swing.JLabel jLabelTituloFormularioClientes;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanelTipoPessoa;
    private javax.swing.JRadioButton jRadioButtonPessoaFisica;
    private javax.swing.JRadioButton jRadioButtonPessoaJuridica;
    private javax.swing.JScrollPane jScrollPaneDetalhes;
    private javax.swing.JTextArea jTextAreaDetalhes;
    private javax.swing.JTextField jTextFieldBairro;
    private javax.swing.JTextField jTextFieldCelular;
    private javax.swing.JTextField jTextFieldCep;
    private javax.swing.JTextField jTextFieldCidade;
    private javax.swing.JTextField jTextFieldComplemento;
    private javax.swing.JTextField jTextFieldCpf;
    private javax.swing.JTextField jTextFieldDdd;
    private javax.swing.JTextField jTextFieldEmail;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldOrgaoExpeditor;
    private javax.swing.JTextField jTextFieldRg;
    private javax.swing.JTextField jTextFieldRua;
    private javax.swing.JTextField jTextFieldTelefone;
    // End of variables declaration//GEN-END:variables
}
