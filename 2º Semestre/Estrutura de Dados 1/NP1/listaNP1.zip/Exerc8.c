lista *circular_normal(lista *l){
	lista *p = l;
	if(p->prox == l){
		p->prox = NULL;
		return p;
	}
	do{
		p = p->prox;
	}while(p->prox != l);
	p->prox = NULL;
	return l;
}