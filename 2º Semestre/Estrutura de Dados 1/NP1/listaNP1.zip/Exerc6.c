lista *remover(lista *l, lista *tmp){
	lista *aux, *p = tmp, *ant, *q = l;
	while(q != NULL){
		while(p != NULL){
			if(p->c == q->c){
				if(q == l){
					l = l->prox;
					free(q);
					q = l;
					ant = l;
				}else if(q->prox == NULL){
					free(q);
					ant->prox = NULL;
					q = ant;
				}else{
					aux = q;
					q = q->prox;
					free(aux);
					ant->prox = q;
				}
			}
			p = p->prox;
		}
		p = tmp;
		ant = q;
		q = q->prox;
	}
	return l;
}