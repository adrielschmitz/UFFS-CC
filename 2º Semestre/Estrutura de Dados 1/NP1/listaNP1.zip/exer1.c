#include <stdio.h>
#include <stdlib.h>

typedef struct _lista{
	int num;
	struct _lista *prox;
}lista;

lista *inicializa();
lista *inicio(lista *l, int n);
lista *fim(lista *l, int n);
lista *meio(lista *l, int n);
lista *exclui(lista *l, int n);
lista *concatenar(lista *l, lista *p)
void imprime(lista *l);
void conta_numero(lista *l);

int main(){
	lista *l;
	l = inicializa();
	conta_numero(l);
	l = inicio(l, 6);
	conta_numero(l);
	l = inicio(l, 12);
	l = fim(l, 3);
	l = meio(l, 7);
	imprime(l);
	conta_numero(l);
	return 0;
}

lista *inicializa(){
	return NULL;
}

lista *inicio(lista *l, int n){
	lista *p = l, *novo = (lista *)malloc(sizeof(lista));
	if(l == NULL){
		novo->num = n;
		novo->prox = novo;
		return novo;
	}
	while(p->prox != l){
		p = p->prox;
	}
	novo->num = n;
	novo->prox = l;
	p->prox = novo;
	return novo;
}

lista *fim(lista *l, int n){
	if(l == NULL){
		l = inicio(l, n);
		return l;
	}
	lista *p;
	p = l;
	while(p->prox != l){
		p = p->prox;
	}
	p->prox = inicio(p->prox, n);
	return l;
}

lista *meio(lista *l, int n){
	if(l == NULL){
		l = inicio(l, n);
		return l;
	}
	lista *p, *aux;
	p = aux = l;
	if(p->num < n){
		l = inicio(l, n);
		return l;
	}
	do{
		if(p->num <= n){
			aux->prox = inicio(aux->prox, n);
			return l;
		}
		aux = p;
		p = p-> prox;
	}while(p != l);
	l = fim(l, n);
	return l;
}

lista *exclui(lista *l, int n){
	lista *p, *aux = NULL;
	p = l;
	while(p->prox != l && p->num != n){
		aux = p;
		p = p->prox;
	}
	if(p->num != n){
		printf("\nNumero nao encontrado!\n\n");
		return l;
	}else{
		if(aux == NULL){
			p = l->prox;
			while(p != l){
				aux = p;
				p = p->prox;
			}
			aux->prox = p->prox;
			free(p);
			return aux->prox;
		}else{
			aux->prox = p->prox;
			free(p);
			return l;
		}
	}
}

void imprime(lista *l){
	lista *p;
	p = l;
	printf("\n");
	if(p == NULL){
		printf("Nao ha nenhum numero na lista\n");
	}else{
		do{
			printf("Numero: %d\n", p->num);
			p = p->prox;
		}while(p != l);
		printf("\n");
	}
}

void conta_numero(lista *l){
	if(l == NULL){
		printf("Nao ha nenhum elemento na lista!\n");
	}
	int cont = 1;
	lista *p;
	p = l;
	while(p->prox != l){
		p = p->prox;
		cont++;
	}
	printf("Quantidade de elementos na lista: %d\n", cont);
}

lista *concatenar(lista *l, lista *p){
	lista *aux1 = l, *aux2=p->prox;
	while(aux1->prox != l){
		aux1 = aux1->prox;
	}
	while(aux2->prox != p){
		aux2 = aux2->prox;
	}
	aux1->prox = p;
	aux2->prox = l;
	return l;
}
