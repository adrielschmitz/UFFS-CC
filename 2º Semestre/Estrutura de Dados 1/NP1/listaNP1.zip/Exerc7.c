lista *normal_circular(lista *l){
	lista *p = l;
	while(p->prox != NULL){
		p = p->prox;
	}
	p->prox = l;
	return l;
}