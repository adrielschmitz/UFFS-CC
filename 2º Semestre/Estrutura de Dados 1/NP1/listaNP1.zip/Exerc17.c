int comprimento(lista *l){
	int cont = 0;
	while(l != NULL){
		cont++;
		l = l->prox;
	}
	return cont;
}