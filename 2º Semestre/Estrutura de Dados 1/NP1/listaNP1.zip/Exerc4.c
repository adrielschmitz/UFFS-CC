#include <stdio.h>
#include <stdlib.h>

typedef struct _lista{
	char c;
	struct _lista *prox;
	struct _lista *ant;
}lista;

void imprime(lista *l);

lista *converte(char v[]){
	int i = 0;
	lista *novo, *inicio, *ant;
	while(v[i] != '\n'){
		if(i == 0){
			novo = (lista *)malloc(sizeof(lista));
			inicio = novo;
			novo->c = v[i];
			novo->prox = NULL;
			novo->ant = NULL;
			ant = novo;
		}else{
			novo = (lista *)malloc(sizeof(lista));
			novo->c = v[i];
			novo->prox = NULL;
			novo->ant = ant;
			ant->prox = novo;
			ant = novo;
		}
		i++;
	}
	return inicio;
}

lista *inverte1(lista *l){
	int i = 0;
	lista *novo, *inicio, *ant, *aux;
	while(l->prox != NULL){
		l = l->prox;
	}
	while(l != NULL){
		if(i == 0){
			novo = (lista *)malloc(sizeof(lista));
			inicio = novo;
			novo->c = l->c;
			novo->prox = NULL;
			novo->ant = NULL;
			ant = novo;
		}else{
			novo = (lista *)malloc(sizeof(lista));
			novo->c = l->c;
			novo->prox = NULL;
			novo->ant = ant;
			ant->prox = novo;
			ant = novo;
		}
		aux = l;
		l = l->ant;
		free(aux);
		i++;
	}
	return inicio;
}

lista *inverte2(lista *l){
	lista *inicio, *fim, *ant, *prox, *aux = l;
	while(l != NULL){
		if(l->c != 'a' && l->c != 'e' && l->c != 'i' && l->c != 'o' && l->c != 'u' && l->c != 'A' && l->c != 'E' && l->c != 'I' && l->c != 'O' && l->c != 'U'){
			inicio = fim = l;
			while(l->prox != NULL && l->c != 'a' && l->c != 'e' && l->c != 'i' && l->c != 'o' && l->c != 'u' && l->c != 'A' && l->c != 'E' && l->c != 'I' && l->c != 'O' && l->c != 'U'){
				l = l->prox;
			}
			fim = l->ant;
			if(inicio != fim){
				if(inicio->ant == NULL){
					prox = fim->prox;
					fim->prox = NULL;
					inicio = inverte1(inicio);
					aux = inicio;
					while(inicio->prox != NULL){
						inicio = inicio->prox;
					}
					prox->ant = inicio;
					inicio->prox = prox;
				}else if(fim->prox == NULL){
					ant = inicio->ant;
					inicio = inverte1(inicio);
					ant->prox = inicio;
					inicio->ant = ant;
				}else{
					ant = inicio->ant;
					prox = fim->prox;
					inicio->ant = NULL;
					fim->prox = NULL;
					inicio = inverte1(inicio);
					ant->prox = inicio;
					inicio->ant = ant;
					while(inicio->prox != NULL){
						inicio = inicio->prox;
					}
					prox->ant = inicio;
					inicio->prox = prox;
				}
			}
		}
		l = l->prox;
	}
	return aux;
}

void imprime(lista *l){
	while(l != NULL){
		printf("%c", l->c);
		l  = l->prox;
	}
	printf("\n");
}

int main(){
	lista *l;
	char v[100];
	fgets(v, 100, stdin);
	l = converte(v);
	l = inverte2(l);
	l = inverte1(l);
	imprime(l);
	return 0;
}