lista *separa(lista *l, int n){
	lista *aux = l, *p;
	while(aux != NULL && aux->num != n){
		aux = aux->prox;
	}
	p = aux->prox;
	aux->prox = NULL;
	return p;
}