int compara(lista *l, lista *p){
	while(l != NULL && p != NULL){
		if(p->num != l->num){
			return 0;
		}
		p = p->prox;
		l = l->prox;
	}
	if(l == NULL && p != NULL){
		return 0;
	}else if(p == NULL && l != NULL){
		return 0;
	}
	return 1;
}